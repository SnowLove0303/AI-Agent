# MSDS Skill / TDS Skill

仓库同时收纳两个独立 Skill：`MSDS Skill/` 处理 MSDS；`TDS Skill/` 处理 TDS。TDS 不复用 MSDS 业务代码，只有相同的工程质量要求：源事实保真、模板几何锁定、受控覆写、DOCX 派生 PDF、八文件包审计和用户校对门槛。

TDS 当前正式基线为四个用户提供的中英文/冠志国彩模板，版本 `1.0.0`。模板来源、active DOCX、注册表和结构快照均在本目录内留有证据。

