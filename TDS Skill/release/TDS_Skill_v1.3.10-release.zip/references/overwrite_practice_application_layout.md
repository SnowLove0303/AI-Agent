# 覆写参考实践：应用正文多行布局与序号清理

这是一条已通过用户验收的 TDS 覆写参考实践，适用于“应用”正文同时出现多行文本、手工序号残留和换行首字错位的场景。它记录处理方法，不包含任何产品文件、产品 mapping 或产品审计产出。

## 目标与边界

本实践只修复 `product.application` 的呈现层：

- 每一行正文使用统一的正文起点，换行后的首字不回到段落左边界。
- 清除应用正文行首的残留手工序号（如 `1.`、`2.`、`1、`），避免出现缺少 `1.` 却从 `2.` 起号的错误序列。
- 保留原始抽取结果、source value、provenance 和 approved mapping 作为证据，不在呈现修复中篡改事实账本。
- 不改变产品特性、性能指标、表格结构、页眉页脚、模板基线或其他章节。

应用模板是普通正文槽位，不是自动编号列表。因此，除非用户明确要求应用采用编号列表，否则应用中的手工序号应作为呈现噪声清理，不重新生成自动编号。

## 定位流程

### 1. 先锁定唯一输入、模板和仓库边界

确认三类路径：

1. 对应产品源文件和 approved mapping；
2. 四个 active 模板及四个最终产出变体；
3. 仓库根与仓库外的产品 `output-dir`。

产品 Word、PDF、mapping、审计报告、generation record、执行日志和其他产品中间文件必须位于仓库外；不得把它们作为 Git 修改处理。

### 2. 逐层比对应用文本

按以下顺序检查，而不是先改 DOCX：

1. 查看 source extraction 中 `product.application` 的原文；
2. 查看 approved mapping 中 `normalized_values` 的最终呈现值；
3. 查看输出 DOCX 的应用标题之后正文段落；
4. 对比模板同一正文槽位的段落属性；
5. 最后检查生成 PDF 的视觉位置。

如果 source extraction 和 approved mapping 都已经带有字面量 `2.`，则序号问题来自事实进入呈现层的原文，不是 PDF 转换造成的；应在覆写边界清理呈现文本，但不能删除源证据。

### 3. 检查 OOXML 的实际原因

重点检查应用正文段落的：

- `w:ind/@w:firstLineChars` 或 `w:firstLine`；
- `w:ind/@w:startChars` 或 `w:start`；
- `w:numPr`；
- `w:tabs`；
- 段落中是否通过 `<w:br/>` 硬换行；
- 是否存在多个独立段落或只是一个段落内的多行文字。

典型故障是：模板示例只有一行，但正文槽位保留了 `firstLineChars=200`；覆写时把多行字符串写入同一段落，python-docx 生成 `<w:br/>`。首行缩进只作用于第一行，第二行便回到段落左边界，于是视觉上出现换行首字不对齐。

## 最小修复规则

### 1. 只在 application 呈现层清理序号

使用等价于以下规则的受控清理：

```python
def application_text(text):
    return "\n".join(
        re.sub(r"^\s*\d+[.、]\s*", "", line).strip()
        for line in (text or "").splitlines()
        if line.strip()
    )
```

注意：

- 只作用于 `product.application`；
- 不要把这个规则推广到所有字段；
- `product.features` 有独立的编号契约，必须继续使用自己的列表处理逻辑；
- 不能通过修改 approved mapping 来掩盖源证据中的序号问题。

### 2. 统一多行应用正文的正文起点

应用正文写入后，移除 `firstLine`/`firstLineChars`，设置统一的字符起点，例如：

```xml
<w:ind w:startChars="200"/>
```

这样同一段落中的首行和 `<w:br/>` 后续行都会从同一条正文基准线开始。只修改应用正文段落的缩进属性，不改其他章节的段落属性。

不要用连续空格、Tab 或手工补位来模拟对齐；这些做法在字体、语言和 PDF 转换后不稳定。

## 验证闭环

修复后必须完成以下检查：

1. 单元测试：应用文本中不存在错误 `2.`，存在换行时 `startChars` 一致且不再有 `firstLineChars`；
2. 完整回归测试：覆写技能全套测试通过；
3. 四变体 DOCX 重建：CN/EN × 冠志/国彩 全部生成；
4. PDF 只从新 DOCX 派生，不独立排版；
5. OOXML 检查：应用正文无 `numPr`，无错误序号，换行结构符合预期；
6. 发布审计：四 DOCX、四 PDF、模板几何、事实保真、性能表 parity 和泄漏检查全部通过；
7. 视觉检查：至少查看一份中文 PDF 和一份英文 PDF 的应用区域，确认两行首字在同一竖直基准线上；
8. 产出目录检查：`WORD/`、`PDF/`、`audit/generation/`、`audit/execution_logs/` 分层存在，产品产出没有进入 Git 状态。

机器审计通过只代表可以交给用户校对；完成用户确认后，才能将该处理标记为正确实践。

## 常见错误做法

- 只在 PDF 中移动文字，不修复 DOCX 的段落结构；
- 直接改源 mapping，导致原始证据丢失；
- 全局删除所有数字前缀，破坏产品特性自动编号；
- 在正文中插入空格或 Tab 解决对齐；
- 直接修改 active 模板基线来适应单个产品；
- 只验证一个变体，漏掉 EN 或另一家公司模板；
- 将产品 Word、PDF、日志或 mapping 加入仓库后再补 `.gitignore`。
